LogoutHook
==========

## Installation
```sudo defaults write com.apple.loginwindow LogoutHook /path/to/LogoutHook.command```

or

```/path/to/LogoutHook.command install```
