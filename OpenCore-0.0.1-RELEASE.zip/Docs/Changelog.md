OpenCore Changelog
==================

#### v0.0.1
- Initial developer preview release
